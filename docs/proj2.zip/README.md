https://github.com/rauldoe/cpsc551proj2 


pip3 install --user PyYAML
or 
pip3 install PyYAML
gem install xmlrpc 
gem install foreman
clear; python arithmetic_client.py

clear; foreman start -f Procfile.1
clear; foreman start -f Procfile.2


